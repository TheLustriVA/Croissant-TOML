"""
Croissant TOML Converter - Convert between Croissant JSON-LD and human-readable TOML.
"""

__version__ = "0.1.0"
